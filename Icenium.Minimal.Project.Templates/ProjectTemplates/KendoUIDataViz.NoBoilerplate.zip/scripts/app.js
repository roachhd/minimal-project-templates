(function (global) {
    global.app = global.app || {};

    document.addEventListener("deviceready", function () {
        global.app.application = new kendo.mobile.Application(document.body, { transition: "", layout: "mobile-tabstrip" });
    }, false);
})(window);